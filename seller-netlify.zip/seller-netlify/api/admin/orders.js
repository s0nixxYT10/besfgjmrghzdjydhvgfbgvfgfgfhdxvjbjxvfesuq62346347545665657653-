const { allOrders, getOrder, saveOrder } = require('../../lib/db');
const { isAdmin, body } = require('../../lib/session');

const STATUSES = ['new', 'confirmed', 'shipping', 'delivered', 'cancelled'];

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (!isAdmin(req)) return res.status(401).json({ error: 'auth' });
  try {
    if (req.method === 'GET') return res.status(200).json({ orders: await allOrders() });
    if (req.method === 'PATCH') {
      const b = body(req);
      const o = await getOrder(String(b.id || ''));
      if (!o) return res.status(404).json({ error: 'Заказ не найден' });
      if (b.status !== undefined) {
        if (!STATUSES.includes(b.status)) return res.status(400).json({ error: 'Неверный статус' });
        o.status = b.status;
      }
      if (b.deliveryDate !== undefined) {
        const d = String(b.deliveryDate);
        if (d && !/^\d{4}-\d{2}-\d{2}$/.test(d)) return res.status(400).json({ error: 'Неверная дата' });
        o.deliveryDate = d;
      }
      await saveOrder(o);
      return res.status(200).json({ order: o });
    }
    res.status(405).end();
  } catch (e) {
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};
