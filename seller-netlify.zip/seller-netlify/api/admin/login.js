const crypto = require('crypto');
const { sign, cookie, body } = require('../../lib/session');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).end();
  let pw = '';
  try { pw = String(body(req).password || ''); } catch (e) {}
  const real = process.env.ADMIN_PASSWORD || '';
  const h = (s) => crypto.createHash('sha256').update(s).digest();
  if (!real || !crypto.timingSafeEqual(h(pw), h(real))) {
    await new Promise((r) => setTimeout(r, 800));
    return res.status(401).json({ error: 'Неверный пароль' });
  }
  res.setHeader('Set-Cookie', cookie('admin', sign({ admin: 1 }, 60 * 60 * 12), 60 * 60 * 12));
  res.status(200).json({ ok: true });
};
