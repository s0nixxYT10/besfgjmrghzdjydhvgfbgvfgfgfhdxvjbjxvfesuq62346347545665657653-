const { cookie } = require('../../lib/session');

module.exports = (req, res) => {
  res.setHeader('Set-Cookie', cookie('admin', '', 0));
  res.status(200).json({ ok: true });
};
