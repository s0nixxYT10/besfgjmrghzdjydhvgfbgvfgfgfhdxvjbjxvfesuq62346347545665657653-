const { cmd, saveOrder } = require('../lib/db');
const { body } = require('../lib/session');
const notify = require('../lib/notify');

const clean = (v, n) => String(v || '').trim().slice(0, n);

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Метод не поддерживается' });
  try {
    const b = body(req);
    const name = clean(b.name, 80), phone = clean(b.phone, 30);
    if (!name || phone.replace(/\D/g, '').length < 9) {
      return res.status(400).json({ error: 'Проверьте имя и номер телефона' });
    }
    const items = (Array.isArray(b.items) ? b.items : []).slice(0, 50).map((i) => ({
      name: clean(i && i.name, 120),
      price: Math.max(0, Math.round(+(i && i.price)) || 0),
      qty: Math.min(99, Math.max(1, Math.round(+(i && i.qty)) || 1)),
    })).filter((i) => i.name);
    if (!items.length) return res.status(400).json({ error: 'Корзина пуста' });

    const n = await cmd(['INCR', 'orders:seq']);
    const order = {
      id: String(1000 + n),
      createdAt: Date.now(),
      name, phone,
      address: clean(b.address, 200),
      comment: clean(b.comment, 300),
      items,
      total: items.reduce((s, i) => s + i.price * i.qty, 0),
      status: 'new',
      deliveryDate: '',
    };
    await saveOrder(order);
    await notify(order);
    res.status(200).json({ ok: true, id: order.id });
  } catch (e) {
    res.status(500).json({ error: 'Не удалось сохранить заказ. Попробуйте ещё раз.' });
  }
};
