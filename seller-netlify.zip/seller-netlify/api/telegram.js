// Вебхук бота: /start -> пароль -> вход админа; кнопки статусов; /orders, /date, /logout
const crypto = require('crypto');
const { cmd, getOrder, saveOrder, allOrders } = require('../lib/db');
const { tg } = require('../lib/tg');
const { body, hookSecret } = require('../lib/session');
const notify = require('../lib/notify');
const { orderText, keyboard, STATUS } = notify;

const h = (s) => crypto.createHash('sha256').update(String(s)).digest();
const safeEq = (a, b) => crypto.timingSafeEqual(h(a), h(b));
const isAdminChat = async (id) => (await cmd(['SISMEMBER', 'admins', String(id)])) === 1;
const HELP = '/orders — oxirgi buyurtmalar\n/date 1005 2026-10-25 — yetkazish sanasi\n/logout — chiqish';

async function onMessage(m) {
  if (!m.chat || m.chat.type !== 'private') return;
  const chat = m.chat.id;
  const text = String(m.text || '').trim();
  const say = (t, extra) => tg('sendMessage', { chat_id: chat, text: t, ...(extra || {}) });

  if (!(await isAdminChat(chat))) {
    if (text === '/start') return say('Salom! Admin paneliga kirish uchun parolni yozing.');
    if (text.startsWith('/')) return say('Avval /start bosing va parolni yozing.');
    const key = 'fail:' + chat;
    const n = await cmd(['INCR', key]);
    if (n === 1) await cmd(['EXPIRE', key, 900]);
    if (n > 5) return say('Juda ko‘p urinish. 15 daqiqadan keyin qayta urinib ko‘ring.');
    const pw = process.env.BOT_PASSWORD || '';
    const ok = pw && safeEq(text, pw);
    await tg('deleteMessage', { chat_id: chat, message_id: m.message_id }); // parol chatda qolmasin
    if (!ok) return say('Noto‘g‘ri parol. Qayta urinib ko‘ring.');
    await cmd(['SADD', 'admins', String(chat)]);
    await cmd(['DEL', key]);
    return say('Xush kelibsiz, admin! Endi yangi buyurtmalar shu yerga keladi.\n\n' + HELP);
  }

  if (text === '/start') return say('Siz adminsiz. Yangi buyurtmalar shu yerga keladi.\n\n' + HELP);
  if (text === '/orders') {
    const list = (await allOrders()).slice(0, 10).reverse();
    if (!list.length) return say('Hozircha buyurtma yo‘q.');
    for (const o of list) await say(orderText(o), { reply_markup: { inline_keyboard: keyboard(o.id) } });
    return;
  }
  const d = text.match(/^\/date\s+(\d+)\s+(\d{4}-\d{2}-\d{2})$/);
  if (d) {
    const o = await getOrder(d[1]);
    if (!o) return say('Bunday buyurtma topilmadi.');
    o.deliveryDate = d[2];
    await saveOrder(o);
    return say(`№${o.id}: yetkazish sanasi ${d[2]} qilib qo‘yildi.`);
  }
  if (text === '/logout') {
    await cmd(['SREM', 'admins', String(chat)]);
    return say('Chiqdingiz. Qayta kirish uchun /start bosing.');
  }
  return say('Buyruqlar:\n' + HELP);
}

async function onCallback(q) {
  const chat = q.message && q.message.chat && q.message.chat.id;
  if (!chat || !(await isAdminChat(chat))) {
    return tg('answerCallbackQuery', { callback_query_id: q.id, text: 'Ruxsat yo‘q' });
  }
  const m = String(q.data || '').match(/^st:(\d+):(new|confirmed|shipping|delivered|cancelled)$/);
  if (!m) return tg('answerCallbackQuery', { callback_query_id: q.id });
  const o = await getOrder(m[1]);
  if (!o) return tg('answerCallbackQuery', { callback_query_id: q.id, text: 'Buyurtma topilmadi' });
  o.status = m[2];
  await saveOrder(o);
  await tg('answerCallbackQuery', { callback_query_id: q.id, text: 'Holat: ' + STATUS[o.status] });
  await tg('editMessageText', {
    chat_id: chat,
    message_id: q.message.message_id,
    text: orderText(o),
    reply_markup: { inline_keyboard: keyboard(o.id) },
  });
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).end();
  if (req.headers['x-telegram-bot-api-secret-token'] !== hookSecret()) return res.status(401).end();
  try {
    const u = body(req);
    if (u.callback_query) await onCallback(u.callback_query);
    else if (u.message && u.message.text !== undefined) await onMessage(u.message);
  } catch (e) {}
  res.status(200).json({ ok: true });
};
