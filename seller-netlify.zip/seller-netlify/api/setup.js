// Один раз откройте эту ссылку в браузере: она подключает бота к сайту
const { tg } = require('../lib/tg');
const { hookSecret } = require('../lib/session');

module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  const url = (process.env.SITE_URL || 'https://' + req.headers.host) + '/api/telegram';
  const r = await tg('setWebhook', { url, secret_token: hookSecret(), allowed_updates: ['message', 'callback_query'] });
  res.status(200).send(r && r.ok
    ? 'Tayyor! Bot saytga ulandi: ' + url
    : 'Xatolik: ' + JSON.stringify(r) + '\nTELEGRAM_BOT_TOKEN va SESSION_SECRET ni tekshiring.');
};
