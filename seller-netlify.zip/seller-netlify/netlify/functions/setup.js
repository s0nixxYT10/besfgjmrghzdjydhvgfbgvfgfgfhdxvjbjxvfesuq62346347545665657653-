const adapt = require('../../lib/adapt');
exports.handler = adapt(require('../../api/setup.js'));
