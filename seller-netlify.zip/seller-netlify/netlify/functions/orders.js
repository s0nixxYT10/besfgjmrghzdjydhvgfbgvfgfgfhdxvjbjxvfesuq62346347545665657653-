const adapt = require('../../lib/adapt');
exports.handler = adapt(require('../../api/orders.js'));
