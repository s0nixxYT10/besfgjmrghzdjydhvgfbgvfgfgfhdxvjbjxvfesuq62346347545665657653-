const adapt = require('../../lib/adapt');
exports.handler = adapt(require('../../api/admin/login.js'));
