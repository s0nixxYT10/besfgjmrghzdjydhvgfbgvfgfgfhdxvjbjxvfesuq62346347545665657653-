# Seller Shop: Netlify + Telegram bot (@laseradmin_bot)

Mijoz saytda buyurtma beradi, buyurtma bazaga yoziladi va parol bilan kirgan adminlarning Telegramiga keladi.
Botdagi tugmalar bilan holatni o‘zgartirish mumkin: Tasdiqlash, Yo‘lda, Yetkazildi, Bekor qilish.

MUHIM: Netlify Drop (papkani tortib tashlash) funksiyalarni qo‘llamaydi. Shuning uchun bu variant GitHub orqali ulanadi.

## 1. Baza (Upstash Redis, bepul)
1. console.upstash.com da akkaunt oching → Create Database (Redis) → istalgan nom va region.
2. Baza sahifasida REST API bo‘limidan UPSTASH_REDIS_REST_URL va UPSTASH_REDIS_REST_TOKEN ni nusxalang.

## 2. GitHub
1. github.com da bepul akkaunt oching va yangi repozitoriy yarating.
2. Zip ichidagi hamma narsani (public, netlify, api, lib, netlify.toml, package.json) yuklang: Add file → Upload files.

## 3. Netlify
1. Eski seller-shop saytini o‘chiring yoki nomini o‘zgartiring (Site configuration → Change site name), aks holda nom band bo‘ladi.
2. app.netlify.com → Add new project → Import an existing project → GitHub → repozitoriyni tanlang → Deploy.
3. Site configuration → Change site name → seller-shop.

## 4. Parollar
Site configuration → Environment variables → .env.example dagi hamma o‘zgaruvchini qo‘shing:
TELEGRAM_BOT_TOKEN, BOT_PASSWORD, SESSION_SECRET, UPSTASH_REDIS_REST_URL, UPSTASH_REDIS_REST_TOKEN (ADMIN_PASSWORD ixtiyoriy).
Keyin Deploys → Trigger deploy → Deploy project.

## 5. Botni ulang (bir marta)
Brauzerda oching: https://seller-shop.netlify.app/api/setup
«Tayyor! Bot saytga ulandi» chiqsa, hammasi ishlaydi.

## 6. Tekshiring
@laseradmin_bot ga /start → parol → «Xush kelibsiz, admin!». Saytdan test buyurtma bering: u botga keladi.

## Bot buyruqlari
/orders: oxirgi 10 ta buyurtma · /date 1005 2026-10-25: yetkazish sanasi · /logout: chiqish

## Muhim
- Parolni kodga yozmang, faqat Environment variables ga kiriting. Tokenni ham hech kimga bermang.
- Parol xabari chatdan o‘chiriladi. 5 marta xato bo‘lsa, 15 daqiqaga bloklanadi.
- Narxlar mijozning brauzeridan keladi. Onlayn to‘lov qo‘shsangiz, katalogni serverga ko‘chirish kerak.
- Saytdagi «Qo‘llab-quvvatlash» formasi hali hech narsani saqlamaydi.
